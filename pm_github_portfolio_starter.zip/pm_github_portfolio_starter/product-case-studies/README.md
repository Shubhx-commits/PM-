# Product Case Studies

A practical collection of product teardowns and improvement proposals.

## What each case study covers
- Context and target user
- User problem and supporting evidence
- Current journey / experience
- Root-cause analysis
- Opportunity sizing and prioritisation
- Proposed solution and trade-offs
- Success metrics, guardrails, and experiment plan

## Case studies
Add each case as a separate folder, for example:

```text
case-name/
├── README.md
├── user-journey.md
├── analysis.md
└── experiment-plan.md
```

## Important note
These are independent analyses unless explicitly labelled otherwise. Do not present a proposal as a shipped feature or a measured result.
