# Product Metrics Playbook

A reference for defining and using product metrics.

## Core metric concepts
- **North Star Metric:** A measure that captures recurring user value delivered by the product.
- **Acquisition:** How users discover and arrive.
- **Activation:** Whether users reach an initial value moment.
- **Engagement:** How frequently and deeply users use the product.
- **Retention:** Whether users return over time.
- **Revenue:** Whether value creation translates into sustainable business outcomes.

## Funnel template
| Stage | Metric | Definition | Segment cuts | Common failure modes |
|---|---|---|---|---|
| Visit | | | | |
| Signup | | | | |
| Activation | | | | |
| Core action | | | | |
| Retention | | | | |
| Revenue | | | | |

## Metric review checklist
- Is the numerator and denominator explicit?
- Is the event definition stable?
- Is the time window appropriate?
- Are cohorts and segments comparable?
- Could a guardrail metric reveal harm?
- Does the metric reflect user value, not just activity?

Add worked examples with assumptions clearly separated from observed data.
