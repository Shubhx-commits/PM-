# Product Growth Experiments

A repository for documenting growth hypotheses and experiment designs.

## Experiment template
### 1. Problem
What user or business problem are we trying to solve?

### 2. Evidence
What quantitative or qualitative evidence suggests this is a real problem?

### 3. Hypothesis
We believe **[change]** for **[user segment]** will improve **[user outcome]** because **[reason]**.

### 4. Experiment design
- Target segment:
- Control:
- Treatment:
- Randomisation unit:
- Duration / sample-size approach:
- Dependencies:

### 5. Metrics
- Primary success metric:
- Guardrail metrics:
- Diagnostic metrics:

### 6. Risks and interpretation
What could bias the result? What would make the experiment inconclusive?

### 7. Result and learning
Record actual results only after the experiment has run. Include confidence / uncertainty and next steps.

*Do not invent experiment outcomes. Clearly label proposed experiments as proposals.*
