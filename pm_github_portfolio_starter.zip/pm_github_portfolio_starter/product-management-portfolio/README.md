# Product Management Portfolio

A collection of product work, case studies, and decision-making examples.

## About
I am a pre-final-year student at IIT (BHU), exploring product management through internships, product case competitions, and independent case studies.

## Selected work
- **Zostel** — Product internship work across discovery, conversion, and guest experience. Add only work you are permitted to share.
- **Carbn** — Research and go-to-market positioning for cross-border B2B payments. Add only work you are permitted to share.
- **PMx** — National finalist. Add the exact competition details and your contribution.

## How I approach product problems
1. Define the user and the problem.
2. Validate the problem with evidence.
3. Identify the root cause rather than jumping to features.
4. Prioritise based on impact, confidence, and effort.
5. Define success metrics and risks.
6. Learn from outcomes and iterate.

## Case studies
Add one folder per project with: `problem.md`, `research.md`, `decision.md`, `metrics.md`, and supporting visuals where permitted.

## Contact
- LinkedIn: [Add your LinkedIn URL]
- Portfolio: https://propellor-site.lovable.app

*This repository is a portfolio index. All claims and metrics should be backed by work you can explain and substantiate.*
