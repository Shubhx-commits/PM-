# SQL for Product Analytics

A growing set of SQL examples for answering product questions.

## Suggested structure
```text
queries/
├── funnel_conversion.sql
├── day_1_retention.sql
├── weekly_active_users.sql
├── cohort_retention.sql
├── feature_adoption.sql
└── experiment_analysis.sql
```

## Query documentation standard
For every query, include:
- Product question
- Table and column assumptions
- SQL query
- Expected output shape
- Interpretation
- Caveats (duplicates, time zones, missing events, identity stitching)

## Example: daily active users
```sql
SELECT
    event_date,
    COUNT(DISTINCT user_id) AS daily_active_users
FROM events
WHERE event_name = 'core_action'
GROUP BY event_date
ORDER BY event_date;
```

This is a template. Replace table and column names to match the actual dataset and document the event definition.
