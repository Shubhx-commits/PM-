# Root Cause Analysis for Product Problems

A working notebook of structured investigations into product metric changes.

## RCA checklist
1. **Confirm the signal:** Is the change real? Check data quality, definitions, instrumentation, and seasonality.
2. **Scope the impact:** When did it start? Which users, platforms, geographies, and segments are affected?
3. **Decompose the metric:** Break the outcome into its component steps or drivers.
4. **Form hypotheses:** Consider product changes, operational issues, user mix, external factors, and measurement issues.
5. **Test hypotheses:** Compare cohorts, timelines, funnels, and control groups where possible.
6. **Identify the root cause:** Separate correlation from evidence of causation.
7. **Recommend action:** State the fix, owner, expected impact, risks, and validation plan.

## Case log
For every investigation, record:
- Problem statement
- Metric definition and baseline
- Timeline
- Segment-level cuts
- Hypotheses and evidence for/against
- Root cause (or what remains unknown)
- Recommended action
- Follow-up metric

*Practice cases must be labelled as practice. Do not imply access to private company data.*
